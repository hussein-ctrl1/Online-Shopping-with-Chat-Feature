package com.example.Data;

import android.graphics.Bitmap;

import com.google.firebase.database.Exclude;
import com.google.firebase.database.IgnoreExtraProperties;

import java.util.HashMap;
import java.util.Map;
@IgnoreExtraProperties
public class Post {

    private String uid;
    private double lat;
    private double lng;
    private String address;
    private String description;
    private String firstName;
    private String lastName;
    private String subCategory;
    private String  Image;
    private String phoneNum;
    private String condition;
    private String title;
    private String status;

    public Post(){};

    public Post(String UID,double lat,double lng, String address,String description,String fName,String lName,String subCat,String Image,String phoneNum,String condition,String title,String status){
        this.uid=UID;
        this.lat=lat;
        this.lng=lng;
        this.address=address;
        this.condition=condition;
        this.Image=Image;
        this.subCategory=subCat;
        this.status=status;
        this.title=title;
        this.firstName=fName;
        this.lastName=lName;
        this.phoneNum=phoneNum;
        this.description=description;
    }

    public String getUid() { return uid; }

    public void setUid(String uid) { this.uid = uid; }

    public double getLat() { return lat; }

    public void setLat(double lat) { this.lat = lat; }

    public double getLng() { return lng; }

    public void setLng(double lng) { this.lng = lng; }

    public String getAddress() { return address; }

    public void setAddress(String address) { this.address = address; }

    public String getDescription() { return description; }

    public void setDescription(String description) { this.description = description; }

    public String getFirstName() { return firstName; }

    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }

    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getSubCategory() { return subCategory; }

    public void setSubCategory(String subCategory) { this.subCategory = subCategory; }

    public String  getImage() { return Image; }

    public void setImage(String image) { Image = image; }

    public String getPhoneNum(String phoneNum) { return this.phoneNum; }

    public void setPhoneNum(String phoneNum) { this.phoneNum = phoneNum;}

    public String getCondition() { return condition; }

    public void setCondition(String condition) { this.condition = condition; }

    public String getTitle() { return title; }

    public void setTitle(String title) { this.title = title; }

    public String getStatus() { return status; }

    public void setStatus(String status) { this.status = status; }

    @Exclude
    public Map<String, Object> toMap() {
        HashMap<String, Object> result = new HashMap<>();
        result.put("uid", uid);
        result.put("latitude", lat);
        result.put("title", title);
        result.put("longitude", lng);
        result.put("address", address);
        result.put("First Name", firstName);
        result.put("Last Name", lastName);
        result.put("SubCategory", subCategory);
        result.put("status", status);
        result.put("condition", condition);
        result.put("phone Number", phoneNum);
        result.put("Image", Image);
        result.put("Description",description);
        return result;
    }
}
