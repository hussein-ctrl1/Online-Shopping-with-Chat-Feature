package com.example.activity.launch;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.example.mobiledevelopmentproject.R;
import com.example.services.LocationService;
import com.google.firebase.FirebaseException;
import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.hbb20.CountryCodePicker;

import java.util.concurrent.TimeUnit;

import static com.google.firebase.auth.PhoneAuthProvider.*;

public class Login extends AppCompatActivity {

    private static final String TAG = "PhoneAuth";

    private EditText phoneText;
    private EditText FirstNameText;
    private EditText LastNameText;
    private Button sendButton;
    private Button resendButton;
    private CheckBox donor;
    private CheckBox recepient;
    private CheckBox donor_recepient;

    protected double latitude, longitude;
    LocationService locationTrack;

    String number;

    String role;

    static String phoneVerificationId;
    private OnVerificationStateChangedCallbacks
            verificationCallbacks;
    private ForceResendingToken resendToken;

    static FirebaseAuth fbAuth;
    CountryCodePicker ccp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_login);
        phoneText = findViewById(R.id.phoneText);
        sendButton = findViewById(R.id.sendButton);
        FirstNameText=findViewById(R.id.FirstName);
        LastNameText=findViewById(R.id.lastName);
        resendButton = findViewById(R.id.resendbutton);
        ccp = findViewById(R.id.ccp);
        donor=findViewById(R.id.donor);
        recepient=findViewById(R.id.recipient);
        donor_recepient=findViewById(R.id.donor_recipient);
        locationTrack = new LocationService(Login.this);
        if (locationTrack.canGetLocation()) {
            longitude = locationTrack.getLongitude();
            latitude = locationTrack.getLatitude();
        } else {
            locationTrack.showSettingsAlert();
        }
        donor.setOnCheckedChangeListener((buttonView, isChecked) -> {
            role= (String) donor.getText();
            recepient.setChecked(false);
            donor_recepient.setChecked(false);
        });
        recepient.setOnCheckedChangeListener((buttonView, isChecked) -> {
            role= (String) recepient.getText();
            donor.setChecked(false);
            donor_recepient.setChecked(false);
        });
        donor_recepient.setOnCheckedChangeListener((buttonView, isChecked) -> {
            role= (String) donor_recepient.getText();
            recepient.setChecked(false);
            donor.setChecked(false);
        });
        if(donor.isChecked()){
            role= (String) donor.getText();
        }
        if(recepient.isChecked()){
            role= (String) recepient.getText();
        }
        if(donor_recepient.isChecked()){
            role= (String) donor_recepient.getText();
        }

        ccp.registerCarrierNumberEditText(phoneText);
        resendButton.setEnabled(false);

            fbAuth = FirebaseAuth.getInstance();
    }

    public void sendCode(View view) {
        boolean fieldsOK = validate(new EditText[]{FirstNameText, LastNameText, phoneText});
        if (fieldsOK && (donor.isChecked() || recepient.isChecked() || donor_recepient.isChecked())) {
            number = ccp.getFullNumberWithPlus();
            locationTrack = new LocationService(Login.this);
            if (locationTrack.canGetLocation()) {
                longitude = locationTrack.getLongitude();
                latitude = locationTrack.getLatitude();
            } else {
                locationTrack.showSettingsAlert();
            }
            setUpVerificatonCallbacks();
            getInstance().verifyPhoneNumber(
                    number,        // Phone number to verify
                    90,                 // Timeout duration
                    TimeUnit.SECONDS,   // Unit of timeout
                    this,               // Activity (for callback binding)
                    verificationCallbacks);
        }
        else{
            Toast.makeText(this,"please fill all inputs",Toast.LENGTH_LONG).show();
        }
    }

    private void setUpVerificatonCallbacks() {

        verificationCallbacks =
                new OnVerificationStateChangedCallbacks() {

                    @Override
                    public void onVerificationCompleted(
                            PhoneAuthCredential credential) {
                        resendButton.setEnabled(false);
                    }

                    @Override
                    public void onVerificationFailed(FirebaseException e) {

                        if (e instanceof FirebaseAuthInvalidCredentialsException) {
                            // Invalid request
                            resendButton.setEnabled(true);
                            resendButton.setBackgroundColor(Color.BLACK);
                            Log.d(TAG, "Invalid credential: "
                                    + e.getLocalizedMessage());
                            Toast.makeText(getBaseContext(),"Invalid credential: "
                                    + e.getLocalizedMessage(),Toast.LENGTH_LONG).show();
                        } else if (e instanceof FirebaseTooManyRequestsException) {
                            // SMS quota exceeded
                            resendButton.setEnabled(true);
                            resendButton.setBackgroundColor(Color.BLACK);
                            Log.d(TAG, "SMS Quota exceeded.");
                            Toast.makeText(getBaseContext(),"SMS Quota exceeded.Please Try Again Later.",Toast.LENGTH_LONG).show();
                        }
                    }

                    @Override
                    public void onCodeSent(String verificationId,
                                           ForceResendingToken token) {
                        phoneVerificationId = verificationId;
                        resendToken = token;
                        Intent intent=new Intent(getApplicationContext(), VerifyCode.class);
                        if(latitude==0.0 && longitude==0.0){
                            locationTrack = new LocationService(Login.this);
                            if (locationTrack.canGetLocation()) {
                                longitude = locationTrack.getLongitude();
                                latitude = locationTrack.getLatitude();
                            } else {
                                locationTrack.showSettingsAlert();
                            }
                        }
                        intent.putExtra("latitude",latitude);
                        intent.putExtra("longitude",longitude);
                        intent.putExtra("FirstName",FirstNameText.getText().toString());
                        intent.putExtra("LastName",LastNameText.getText().toString());
                        intent.putExtra("Role",role);
                        startActivity(intent);
                        sendButton.setEnabled(false);
                        resendButton.setEnabled(false);
                    }
                };
    }

    public void resendCode(View view) {
        number = ccp.getFullNumberWithPlus();
        setUpVerificatonCallbacks();
        getInstance().verifyPhoneNumber(
                number,
                60,
                TimeUnit.SECONDS,
                this,
                verificationCallbacks,
                resendToken);
    }

    private boolean validate(EditText[] fields){
        for(int i = 0; i < fields.length; i++){
            EditText currentField = fields[i];
            if(currentField.getText().toString().length() <= 0){
                return false;
            }
        }
        return true;
    }
}