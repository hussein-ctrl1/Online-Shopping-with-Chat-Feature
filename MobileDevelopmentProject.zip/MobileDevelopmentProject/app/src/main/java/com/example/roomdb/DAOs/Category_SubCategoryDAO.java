package com.example.roomdb.DAOs;


import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.roomdb.ENTITY.Category_SubCategory;

import java.util.List;

@Dao
public interface Category_SubCategoryDAO {

    @Query("Select * from category_subCategory")
    List<Category_SubCategory> getAllCategoriesWithSubCategories();

    @Insert
    void insert(Category_SubCategory... category_subCategories);

    @Insert
    void insertAll(List<Category_SubCategory> category_subCategories);

    @Query("Select distinct category_subCategory.category from category_subCategory")
    List<String> getALLCategories();

    @Query("Select category_subCategory.subCategory from category_subCategory where category_subCategory.category=:Category")
    List<String> getALLSubCategoriesOFCategory(String Category);
}
