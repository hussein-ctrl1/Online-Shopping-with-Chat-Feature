package com.example.activity.Recepient;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.mobiledevelopmentproject.R;

public class RecipientActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_recipient);
    }
}