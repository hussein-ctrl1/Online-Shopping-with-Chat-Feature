package com.example.Implementations;

import com.example.roomdb.ENTITY.Category_SubCategory;

import java.util.ArrayList;
import java.util.List;

public class CategorySubCategoryImplementation {

    public static List<Category_SubCategory> createList(){
        List<Category_SubCategory> category_subCategories=new ArrayList<>();
        category_subCategories.add(new Category_SubCategory(1,"Electonic & Home Appliances","Kitchen Equipment & Appliances"));
        category_subCategories.add(new Category_SubCategory(2,"Electonic & Home Appliances","Cleaning Appliances"));
        category_subCategories.add(new Category_SubCategory(3,"Electonic & Home Appliances","Washing Machines & Dryres"));
        category_subCategories.add(new Category_SubCategory(4,"Electonic & Home Appliances","Other Home Appliances"));
        category_subCategories.add(new Category_SubCategory(5,"Home Furniture & Decor","Home Decoration & Accessories"));
        category_subCategories.add(new Category_SubCategory(6,"Home Furniture & Decor","Other Home Furniture & Decor"));
        category_subCategories.add(new Category_SubCategory(7,"Clothing & Accessories","Clothing for Men"));
        category_subCategories.add(new Category_SubCategory(8,"Clothing & Accessories","Clothing for Women"));
        category_subCategories.add(new Category_SubCategory(9,"Clothing & Accessories","Accessories for Men"));
        category_subCategories.add(new Category_SubCategory(10,"Clothing & Accessories","Accessories for Women"));
        category_subCategories.add(new Category_SubCategory(11,"Kids & Babies","Strollers & Seats"));
        category_subCategories.add(new Category_SubCategory(12,"Kids & Babies","Kids & Babies Clothing"));
        category_subCategories.add(new Category_SubCategory(13,"Kids & Babies","Safety & Monitors"));
        category_subCategories.add(new Category_SubCategory(14,"Kids & Babies","Cribs & Bedroom Furniture"));
        category_subCategories.add(new Category_SubCategory(15,"Kids & Babies","Other for Kids & Babies"));
        return category_subCategories;
    }
}
