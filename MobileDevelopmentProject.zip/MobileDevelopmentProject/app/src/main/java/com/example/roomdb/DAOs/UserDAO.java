package com.example.roomdb.DAOs;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.roomdb.ENTITY.User;

import java.util.List;

@Dao
public interface UserDAO {

    @Query("Select * from USER")
    List<User> getAllUsers();

    @Insert
    void Insert(User... users);

    @Delete
    void Delete(User user);
}
