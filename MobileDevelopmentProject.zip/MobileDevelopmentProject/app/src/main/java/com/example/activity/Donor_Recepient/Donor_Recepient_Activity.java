package com.example.activity.Donor_Recepient;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.mobiledevelopmentproject.R;

public class Donor_Recepient_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_donor__recepient_);
    }
}