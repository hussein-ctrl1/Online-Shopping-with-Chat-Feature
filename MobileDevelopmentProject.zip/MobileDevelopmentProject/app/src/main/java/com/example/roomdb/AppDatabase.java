package com.example.roomdb;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.roomdb.DAOs.Category_SubCategoryDAO;
import com.example.roomdb.DAOs.UserDAO;
import com.example.roomdb.ENTITY.Category_SubCategory;
import com.example.roomdb.ENTITY.User;


@Database(entities={User.class, Category_SubCategory.class},version=1)
public abstract class AppDatabase extends RoomDatabase {

    public abstract UserDAO userDao();
    public abstract Category_SubCategoryDAO category_subCategoryDAO();

    private static AppDatabase INSTANCE;

    public static AppDatabase getInstance(Context context){
        if (INSTANCE==null){
            Builder<AppDatabase> donation_db = Room.databaseBuilder(context.getApplicationContext(), AppDatabase.class, "Donation_DB");
            donation_db.allowMainThreadQueries();
            donation_db.enableMultiInstanceInvalidation();
            INSTANCE= donation_db
                    .build();
        }
        return INSTANCE;
    }

}
