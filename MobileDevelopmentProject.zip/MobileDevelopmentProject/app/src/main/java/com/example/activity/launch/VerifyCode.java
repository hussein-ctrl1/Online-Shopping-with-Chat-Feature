package com.example.activity.launch;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.activity.Donor.DonorActivity;
import com.example.activity.Donor_Recepient.Donor_Recepient_Activity;
import com.example.activity.Recepient.RecipientActivity;
import com.example.mobiledevelopmentproject.R;
import com.example.roomdb.AppDatabase;
import com.example.roomdb.ENTITY.User;
import com.example.services.LocationService;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.List;
import java.util.Locale;

public class VerifyCode extends AppCompatActivity {

    private EditText codeText;
    private  Button verifyBtn;
    public static final String MyPREFERENCES = "MyPrefs" ;
    public static final String Phone = "phoneKey";
    public static final String FirstName = "FirstNameKey";
    public static final String LastName = "LastNameKey";
    SharedPreferences sharedpreferences;


    LocationService locationTrack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_code2);
        getSupportActionBar().hide();
        codeText=findViewById(R.id.codeText);
        verifyBtn=findViewById(R.id.verifyButton);
        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
    }

    public void verifyCode(View view) {
        String code = codeText.getText().toString();
        PhoneAuthCredential credential =
                PhoneAuthProvider.getCredential(Login.phoneVerificationId, code);
        signInWithPhoneAuthCredential(credential);
    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        Login.fbAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            codeText.setText("");
                            verifyBtn.setEnabled(false);
                            FirebaseUser user = task.getResult().getUser();
                            String phoneNumber = user.getPhoneNumber();
                            String userId = user.getUid();
                            SharedPreferences.Editor editor = sharedpreferences.edit();
                            Intent intent = getIntent();
                            editor.putString(Phone, phoneNumber);
                            editor.putString(FirstName, intent.getStringExtra("FirstName"));
                            editor.putString(LastName, intent.getStringExtra("LastName"));
                            AppDatabase appDatabase = AppDatabase.getInstance(getApplicationContext());
                            User User = new User();
                            User.setUid(userId);
                            User.setFName(intent.getStringExtra("FirstName"));
                            User.setLName(intent.getStringExtra("LastName"));
                            User.setPhoneNum(phoneNumber);
                            User.setRole(intent.getStringExtra("Role"));
                            if (User.getLng() == 0.0 && User.getLat() == 0.0) {
                                locationTrack = new LocationService(VerifyCode.this);
                                if (locationTrack.canGetLocation()) {
                                    User.setLng(locationTrack.getLongitude());
                                    User.setLat(locationTrack.getLatitude());
                                    User.setAddress(getCompleteAddressString(User.getLat(), User.getLng()));
                                } else {
                                    locationTrack.showSettingsAlert();
                                }
                                User.setLat(intent.getDoubleExtra("latitude", 0.00));
                                User.setLng(intent.getDoubleExtra("longitude", 0.0));
                                User.setAddress(getCompleteAddressString(User.getLat(), User.getLng()));
                                User.setVerified(true);
                                appDatabase.userDao().Insert(User);
                                editor.commit();
                                if (User.getRole().equalsIgnoreCase("donor") || User.getRole().equalsIgnoreCase("DONOR")) {
                                    Intent DonorIntent = new Intent(VerifyCode.this, DonorActivity.class);
                                    startActivity(DonorIntent);
                                    finish();
                                }
                                if (User.getRole().equalsIgnoreCase("recepient") || User.getRole().equalsIgnoreCase("RECEPIENT")) {
                                    Intent DonorIntent = new Intent(VerifyCode.this, RecipientActivity.class);
                                    startActivity(DonorIntent);
                                    finish();
                                }
                                if (User.getRole().equalsIgnoreCase("donor-recepient") || User.getRole().equalsIgnoreCase("DONOR-RECEPIENT")) {
                                    Intent DonorIntent = new Intent(VerifyCode.this, Donor_Recepient_Activity.class);
                                    startActivity(DonorIntent);
                                    finish();
                                }
                                finish();
                            }
                        }
                        else {
                            if (task.getException() instanceof
                                    FirebaseAuthInvalidCredentialsException) {
                            }
                        }
                    }
                });
    }

    private String getCompleteAddressString(double LATITUDE, double LONGITUDE) {
        String strAdd = "";
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(LATITUDE, LONGITUDE, 1);
            if (addresses != null) {
                Address returnedAddress = addresses.get(0);
                StringBuilder strReturnedAddress = new StringBuilder("");

                for (int i = 0; i <= returnedAddress.getMaxAddressLineIndex(); i++) {
                    strReturnedAddress.append(returnedAddress.getAddressLine(i)).append("\n");
                }
                strAdd = strReturnedAddress.toString();
            } else {
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return strAdd;
    }

}