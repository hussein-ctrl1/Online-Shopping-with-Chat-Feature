package com.example.activity.Donor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import com.example.adapters.category_Adapter;
import com.example.adapters.subCategory_Adapter;
import com.example.mobiledevelopmentproject.R;

import java.util.ArrayList;
import java.util.List;

public class Donor_SubCategoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donor__sub_category);
        getSupportActionBar().hide();
        RecyclerView SubCategories=findViewById(R.id.subCategories);
        Intent getListIntent=getIntent();
        List<String> subCats= (ArrayList<String>) getListIntent.getSerializableExtra("subCategories");
        subCategory_Adapter adapter=new subCategory_Adapter(subCats,this.getApplicationContext());
        SubCategories.setAdapter(adapter);
        SubCategories.setLayoutManager(new LinearLayoutManager(this));
    }
}