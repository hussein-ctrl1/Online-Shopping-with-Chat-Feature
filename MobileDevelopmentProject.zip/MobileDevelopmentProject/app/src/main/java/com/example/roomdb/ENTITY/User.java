package com.example.roomdb.ENTITY;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "user")
public class User {

    @NonNull
    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name="uid")
    private String uid;

    @ColumnInfo(name="first_Name")
    private String FName;

    @ColumnInfo(name="last_Name")
    private String LName;

    @ColumnInfo(name="phone_Num")
    private String phoneNum;

    @ColumnInfo(name="latitude")
    private double lat;

    @ColumnInfo(name="longitude")
    private double lng;

    @ColumnInfo(name="address")
    private String address;

    @ColumnInfo(name="isVerified")
    private Boolean isVerified;

    @ColumnInfo(name="role")
    private String Role;

    public int getId() { return id; }

    public void setId(int id) { this.id = id;
    }
    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getFName() {
        return FName;
    }

    public void setFName(String FName) {
        this.FName = FName;
    }

    public String getLName() {
        return LName;
    }

    public void setLName(String LName) {
        this.LName = LName;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Boolean getVerified() {
        return isVerified;
    }

    public void setVerified(Boolean verified) {
        isVerified = verified;
    }

    public String getRole() {
        return Role;
    }

    public void setRole(String role) {
        Role = role;
    }
}