package com.example.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.activity.Donor.DonorPostActivity;
import com.example.activity.Donor.Donor_SubCategoryActivity;
import com.example.mobiledevelopmentproject.R;

import java.util.ArrayList;
import java.util.List;

public class subCategory_Adapter extends RecyclerView.Adapter<subCategory_Adapter.ViewHolder> {

    private final List<String > SubCategories;
    Context context;

    public subCategory_Adapter(List<String> subCategories,Context context) {
        SubCategories = subCategories;
        this.context=context;
    }

    @NonNull
    @Override
    public subCategory_Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context=parent.getContext();
        LayoutInflater inflater=LayoutInflater.from(context);
        View Sub_CategoryView=inflater.inflate(R.layout.layout,parent,false);
        subCategory_Adapter.ViewHolder viewHolder=new subCategory_Adapter.ViewHolder(Sub_CategoryView);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String subCategory=SubCategories.get(position);
        TextView sub_categoryText;
        sub_categoryText = holder.category_subCategoryText;
        sub_categoryText.setText(subCategory);
        sub_categoryText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent postIntent=new Intent(context, DonorPostActivity.class);
                postIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                postIntent.putExtra("subCategory", subCategory);
                context.startActivity(postIntent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return SubCategories.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView category_subCategoryText;
        private final Context context;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            this.category_subCategoryText=itemView.findViewById(R.id.category_subCategory);
            this.context = itemView.getContext();
        }
    }
}
