package com.example.roomdb.ENTITY;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "category_subCategory")
public class Category_SubCategory {

    @NonNull
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "category_subCategoryId")
    private int category_subCategoryId;

    @ColumnInfo(name = "category")
    private String category;

    @ColumnInfo(name = "subCategory")
    private String subCategory;

    public  Category_SubCategory(){}

    public Category_SubCategory(int id,String category,String subCategory){
        this.category_subCategoryId=id;
        this.category=category;
        this.subCategory=subCategory;
    }

    public void setCategory_subCategoryId(int category_subCategoryId) { this.category_subCategoryId = category_subCategoryId; }

    public int getCategory_subCategoryId() { return category_subCategoryId; }

    public void setCategoryId(int category_subCategoryId) { this.category_subCategoryId = category_subCategoryId;}

    public String getCategory() { return category; }

    public void setCategory(String category) { this.category = category; }

    public String getSubCategory() { return subCategory; }

    public void setSubCategory(String subCategory) { this.subCategory = subCategory; }
}

