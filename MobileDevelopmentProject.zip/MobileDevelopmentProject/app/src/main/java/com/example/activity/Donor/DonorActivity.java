package com.example.activity.Donor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.adapters.category_Adapter;
import com.example.mobiledevelopmentproject.R;
import com.example.roomdb.AppDatabase;
import com.example.roomdb.ENTITY.Category_SubCategory;

import java.util.List;

public class DonorActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_donor);
        RecyclerView Categories=findViewById(R.id.Categories);
        AppDatabase database=AppDatabase.getInstance(getApplicationContext());
        List<String> categoryList=database.category_subCategoryDAO().getALLCategories();
        category_Adapter adapter=new category_Adapter(categoryList,this.getApplicationContext());
        Categories.setAdapter(adapter);
        Categories.setLayoutManager(new LinearLayoutManager(this));
    }
}