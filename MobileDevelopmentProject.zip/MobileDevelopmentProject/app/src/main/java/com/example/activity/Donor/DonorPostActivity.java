package com.example.activity.Donor;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.Data.Post;
import com.example.activity.launch.Login;
import com.example.activity.launch.SplashScreenActivity;
import com.example.mobiledevelopmentproject.R;
import com.example.roomdb.AppDatabase;
import com.example.roomdb.ENTITY.User;
import com.example.services.LocationService;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.Locale;

public class DonorPostActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private Spinner Status;
    private String status;
    private Button donateBtn;
    private EditText titleText;
    private EditText descText;
    private EditText conditionTxt;
    private FloatingActionButton takeImg;
    private ImageView Image;

    LocationService locationTrack;

    Integer REQUEST_CAMERA=1,
            SELECT_FILE=0;
    private static final int MY_CAMERA_REQUEST_CODE = 100;
    DatabaseReference databasePosts;
    StorageReference storageReferences;

    private Uri uri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donor_post);
        getSupportActionBar().hide();
        Status=findViewById(R.id.StatusSpinner);
        databasePosts = FirebaseDatabase.getInstance().getReference("posts");
        storageReferences=FirebaseStorage.getInstance().getReference("uploads");
        ArrayAdapter<CharSequence> adapter=ArrayAdapter.createFromResource(this,R.array.status, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Status.setAdapter(adapter);
        Status.setOnItemSelectedListener(this);
        Image=findViewById(R.id.image_view);
        titleText=findViewById(R.id.title);
        descText=findViewById(R.id.Description);
        conditionTxt=findViewById(R.id.condition);
        takeImg=findViewById(R.id.takeImg);
        takeImg.setOnClickListener(v -> {
            SelectImage();
        });
        donateBtn=findViewById(R.id.Donate);
        donateBtn.setOnClickListener(v -> {
                    if (!status.isEmpty() && validate(new EditText[]{titleText, descText, conditionTxt})) {
                        String postId = databasePosts.push().getKey();
                        AppDatabase database = AppDatabase.getInstance(getApplicationContext());
                        List<User> users = database.userDao().getAllUsers();
                        Post post = new Post();
                        post.setAddress(users.get(0).getAddress());
                        post.setCondition(conditionTxt.getText().toString());
                        post.setDescription(descText.getText().toString());
                        post.setTitle(titleText.getText().toString());
                        post.setFirstName(users.get(0).getFName());
                        post.setLastName(users.get(0).getLName());
                        post.setLat(users.get(0).getLat());
                        post.setLng(users.get(0).getLng());
                        if(users.get(0).getLat()==0.0 && users.get(0).getLng()==0.0 ){
                            locationTrack = new LocationService(DonorPostActivity.this);
                            if (locationTrack.canGetLocation()) {
                                double longitude = locationTrack.getLongitude();
                                double latitude = locationTrack.getLatitude();
                                Toast.makeText(this,"fix location settings,it will save online wrong info",Toast.LENGTH_LONG).show();
                                users.get(0).setLng(longitude);
                                users.get(0).setLat(latitude);
                                users.get(0).setAddress(getCompleteAddressString(latitude,longitude));
                            } else {
                                locationTrack.showSettingsAlert();
                            }
                        }
                        post.getPhoneNum(users.get(0).getPhoneNum());
                        post.setUid(users.get(0).getUid());
                        post.setSubCategory(getIntent().getStringExtra("subCategory"));
                        post.setStatus(status);
                        BitmapDrawable drawable = (BitmapDrawable) Image.getDrawable();
                        Bitmap bitmap = drawable.getBitmap();
                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                        byte[] bytes = baos.toByteArray();
                        StorageReference reference = FirebaseStorage.getInstance().getReference().child("photos/"+users.get(0).getUid().toString()+"&&&&"+System.currentTimeMillis()+".png");
                        UploadTask uploadTask = reference.putBytes(bytes);
                        uploadTask.addOnSuccessListener(taskSnapshot -> {
                            Uri imageUri=taskSnapshot.getUploadSessionUri();
                            post.setImage(imageUri.toString());
                        });
                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                databasePosts.child(postId).setValue(post.toMap());
                            }
                        },7000);
                        Toast.makeText(this,"Posted Successfully",Toast.LENGTH_LONG).show();
            }
            else{
                Toast.makeText(this,"Please Fill Inputs",Toast.LENGTH_LONG).show();
            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        status=parent.getItemAtPosition(position).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    private void SelectImage(){
        final CharSequence[] items={"Camera","Gallery","Cancel"};
        AlertDialog.Builder builder=new AlertDialog.Builder(DonorPostActivity.this);
        builder.setTitle("Add Image");
        builder.setItems(items, (dialog, which) -> {
            if(items[which].equals("Camera")){
                Intent intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (checkSelfPermission(Manifest.permission.CAMERA)
                        != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.CAMERA},
                            MY_CAMERA_REQUEST_CODE);

                }
                startActivityForResult(intent,REQUEST_CAMERA);
            }
            else if(items[which].equals("Gallery")){
                Intent intent=new Intent(Intent.ACTION_PICK,MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                intent.setType("image/*");
                startActivityForResult(intent.createChooser(intent,"Select File"),SELECT_FILE);
            }
            else if(items[which].equals("Cancel")){
                dialog.dismiss();
            }
        });
        builder.show();
    }

    @Override
    public void onActivityResult( int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);

            if(requestCode==REQUEST_CAMERA){

                Bundle bundle = data.getExtras();
                final Bitmap bmp = (Bitmap) bundle.get("data");
                Image.setImageBitmap(bmp);
            }
            else if(requestCode == SELECT_FILE){
                Uri selectImageUrl = data.getData();
                uri=selectImageUrl;
                Image.setImageURI(selectImageUrl);
            }
        }

    @Override

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == MY_CAMERA_REQUEST_CODE) {

            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                Intent intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent,REQUEST_CAMERA);

            } else {

                Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show();

            }

        }
    }
    private boolean validate(EditText[] fields){
        for(int i = 0; i < fields.length; i++){
            EditText currentField = fields[i];
            if(currentField.getText().toString().length() <= 0){
                return false;
            }
        }
        return true;
    }
    private String getCompleteAddressString(double LATITUDE, double LONGITUDE) {
        String strAdd = "";
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(LATITUDE, LONGITUDE, 1);
            if (addresses != null) {
                Address returnedAddress = addresses.get(0);
                StringBuilder strReturnedAddress = new StringBuilder("");

                for (int i = 0; i <= returnedAddress.getMaxAddressLineIndex(); i++) {
                    strReturnedAddress.append(returnedAddress.getAddressLine(i)).append("\n");
                }
                strAdd = strReturnedAddress.toString();
            } else {
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return strAdd;
    }
}