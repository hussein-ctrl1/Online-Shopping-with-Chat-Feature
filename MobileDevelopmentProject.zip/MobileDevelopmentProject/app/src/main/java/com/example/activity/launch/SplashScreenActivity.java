package com.example.activity.launch;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;

import com.example.Implementations.CategorySubCategoryImplementation;
import com.example.activity.Donor.DonorActivity;
import com.example.activity.Donor_Recepient.Donor_Recepient_Activity;
import com.example.activity.Recepient.RecipientActivity;
import com.example.mobiledevelopmentproject.R;
import com.example.roomdb.AppDatabase;
import com.example.roomdb.ENTITY.Category_SubCategory;
import com.example.roomdb.ENTITY.User;

import java.util.List;

public class SplashScreenActivity extends AppCompatActivity{

    private static int SPLASH_TIME_OUT = 3000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        SharedPreferences shared = getSharedPreferences(VerifyCode.MyPREFERENCES, MODE_PRIVATE);
        String phoneNum = shared.getString(VerifyCode.Phone, "");
        String FName = shared.getString(VerifyCode.FirstName, "");
        String LName = shared.getString(VerifyCode.LastName, "");
        setContentView(R.layout.activity_splash_screen);
        AppDatabase database=AppDatabase.getInstance(getApplicationContext());
        List<Category_SubCategory> category_subCategories=database.category_subCategoryDAO().getAllCategoriesWithSubCategories();
        if(category_subCategories==null || category_subCategories.size()==0) {
            database.category_subCategoryDAO().insertAll(CategorySubCategoryImplementation.createList());
        }
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (TextUtils.isEmpty(phoneNum) || phoneNum.isEmpty()) {
                        Intent LoginIntent = new Intent(SplashScreenActivity.this, Login.class);
                        startActivity(LoginIntent);
                        finish();
                    } else {
                        AppDatabase appDatabase = AppDatabase.getInstance(getApplicationContext());
                        List<User> users = appDatabase.userDao().getAllUsers();
                        for (User user : users)
                            if (user.getFName().equalsIgnoreCase(FName) && user.getLName().equals(LName) && user.getPhoneNum().equalsIgnoreCase(phoneNum)) {
                                if (user.getRole().equalsIgnoreCase("donor") || user.getRole().equalsIgnoreCase("DONOR")) {
                                    Intent DonorIntent = new Intent(SplashScreenActivity.this, DonorActivity.class);
                                    startActivity(DonorIntent);
                                    finish();
                                }
                                if (user.getRole().equalsIgnoreCase("recepient") || user.getRole().equalsIgnoreCase("RECEPIENT")) {
                                    Intent DonorIntent = new Intent(SplashScreenActivity.this, RecipientActivity.class);
                                    startActivity(DonorIntent);
                                    finish();
                                }
                                if (user.getRole().equalsIgnoreCase("donor-recepient") || user.getRole().equalsIgnoreCase("DONOR-RECEPIENT")) {
                                    Intent DonorIntent = new Intent(SplashScreenActivity.this, Donor_Recepient_Activity.class);
                                    startActivity(DonorIntent);
                                    finish();
                                }
                            }
                    }
                }
            }, SPLASH_TIME_OUT);
        }
    }

