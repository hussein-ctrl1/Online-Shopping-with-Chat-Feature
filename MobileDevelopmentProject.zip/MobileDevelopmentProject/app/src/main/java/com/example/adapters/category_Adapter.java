package com.example.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.activity.Donor.Donor_SubCategoryActivity;
import com.example.mobiledevelopmentproject.R;
import com.example.roomdb.AppDatabase;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class category_Adapter extends RecyclerView.Adapter<category_Adapter.ViewHolder> {

    private final List<String> Categories;
    Context context;

    public category_Adapter(List<String> categories,Context context) {
        Categories = categories;
        this.context=context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context=parent.getContext();
        LayoutInflater inflater=LayoutInflater.from(context);
        View CategoryView=inflater.inflate(R.layout.layout,parent,false);
        ViewHolder viewHolder=new ViewHolder(CategoryView);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String category=Categories.get(position);
        TextView categoryText=holder.categoryText;
        categoryText.setText(category);
        categoryText.setOnClickListener(v -> {
            AppDatabase database=AppDatabase.getInstance(context);
            List<String> subCategories=database.category_subCategoryDAO().getALLSubCategoriesOFCategory(category);
            Intent subCategoryIntent=new Intent(context, Donor_SubCategoryActivity.class);
            subCategoryIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            subCategoryIntent.putExtra("subCategories", (Serializable) subCategories);
            context.startActivity(subCategoryIntent);
        });
    }

    @Override
    public int getItemCount() {
        return Categories.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        private TextView categoryText;
        private final Context context;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            this.categoryText=itemView.findViewById(R.id.category_subCategory);
            this.context = itemView.getContext();
        }
    }
}
